const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

// Default economy: 10 Coins = 1 EGP of gift earnings.
// Change this mapping here if the business conversion changes.
const GIFT_VALUES_PIASTERS = {
  10: 100,
  20: 200,
  50: 500,
  100: 1000,
  200: 2000,
  500: 5000
};
const MIN_WITHDRAWAL_PIASTERS = 10000;

exports.sendGift = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول');
  const fromUid = request.auth.uid;
  const { toUid, cost, emoji, requestId } = request.data || {};
  if (!toUid || toUid === fromUid) throw new HttpsError('invalid-argument', 'المستلم غير صالح');
  if (!Number.isInteger(cost) || !GIFT_VALUES_PIASTERS[cost]) throw new HttpsError('invalid-argument', 'قيمة الهدية غير صالحة');
  const rid = String(requestId || `${fromUid}_${toUid}_${Date.now()}`);
  const giftRef = db.collection('giftTransactions').doc(rid);
  const senderRef = db.collection('users').doc(fromUid);
  const receiverRef = db.collection('users').doc(toUid);

  await db.runTransaction(async (tx) => {
    const existing = await tx.get(giftRef);
    if (existing.exists) return;
    const sender = (await tx.get(senderRef)).data();
    const receiver = (await tx.get(receiverRef)).data();
    if (!sender || !receiver) throw new HttpsError('not-found', 'الحساب غير موجود');
    const coins = Number(sender.coins || 0);
    if (coins < cost) throw new HttpsError('failed-precondition', 'رصيدك لا يكفي');
    const earning = GIFT_VALUES_PIASTERS[cost];
    tx.update(senderRef, { coins: coins - cost });
    tx.update(receiverRef, { earningsPiasters: Number(receiver.earningsPiasters || 0) + earning });
    tx.set(giftRef, {
      from: fromUid,
      to: toUid,
      cost,
      emoji: String(emoji || ''),
      earningPiasters: earning,
      createdAt: FieldValue.serverTimestamp()
    });
    tx.set(db.collection('gifts').doc(rid), {
      from: fromUid,
      to: toUid,
      cost,
      emoji: String(emoji || ''),
      earningPiasters: earning,
      createdAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true };
});

exports.requestWithdrawal = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول');
  const uid = request.auth.uid;
  const walletType = String(request.data?.walletType || '').trim();
  const walletNumber = String(request.data?.walletNumber || '').trim();
  if (!walletType || !walletNumber) throw new HttpsError('invalid-argument', 'بيانات المحفظة مطلوبة');
  if (!/^[0-9+ -]{8,20}$/.test(walletNumber)) throw new HttpsError('invalid-argument', 'رقم المحفظة غير صالح');

  const userRef = db.collection('users').doc(uid);
  const withdrawalRef = db.collection('withdrawals').doc();
  let amountPiasters = 0;
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(userRef);
    if (!snap.exists) throw new HttpsError('not-found', 'الحساب غير موجود');
    const data = snap.data();
    const balance = Number(data.earningsPiasters || 0);
    if (balance < MIN_WITHDRAWAL_PIASTERS) throw new HttpsError('failed-precondition', 'الحد الأدنى للسحب 100 جنيه');
    amountPiasters = balance;
    tx.update(userRef, { earningsPiasters: 0 });
    tx.set(withdrawalRef, {
      uid,
      amountPiasters,
      walletType,
      walletNumber,
      status: 'pending',
      createdAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true, amountPiasters };
});

exports.setWithdrawalStatus = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'يجب تسجيل الدخول');
  const adminSnap = await db.collection('users').doc(request.auth.uid).get();
  if (!adminSnap.exists || adminSnap.data().role !== 'admin') throw new HttpsError('permission-denied', 'غير مصرح');
  const id = String(request.data?.withdrawalId || '');
  const status = String(request.data?.status || '');
  if (!id || !['paid', 'rejected'].includes(status)) throw new HttpsError('invalid-argument', 'بيانات غير صالحة');
  const ref = db.collection('withdrawals').doc(id);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'طلب السحب غير موجود');
    const w = snap.data();
    if (w.status !== 'pending') return;
    tx.update(ref, { status, reviewedAt: FieldValue.serverTimestamp(), reviewedBy: request.auth.uid });
    if (status === 'rejected') {
      const userRef = db.collection('users').doc(w.uid);
      const u = (await tx.get(userRef)).data();
      tx.update(userRef, { earningsPiasters: Number(u.earningsPiasters || 0) + Number(w.amountPiasters || 0) });
    }
  });
  return { ok: true };
});
